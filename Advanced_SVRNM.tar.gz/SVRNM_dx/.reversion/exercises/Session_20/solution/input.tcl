database -open waves -into waves.shm -default
probe -create -shm -all -dynamic -depth all

